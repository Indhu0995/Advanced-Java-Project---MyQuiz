package fr.epita.quiz.services;

import java.util.Map;

import fr.epita.quiz.datamodel.Options;

public class MCQChoiceDAO extends DAO<Options>{

	@Override
	protected String getQueryString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void fillParametersMap(Map<String, Object> map, Options t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected String getQuestionQueryString() {
		// TODO Auto-generated method stub
		return null;
	}

}
